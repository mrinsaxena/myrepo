package com.example.TradeAssignment.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.TradeAssignment.model.Trade;

/**
 * @author MRIN
 *
 */
@Repository
public interface TradeRepository extends JpaRepository<Trade,String> {
}
